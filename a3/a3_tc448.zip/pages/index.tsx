import Layout from "../components/layout/Layout"

const IndexPage = () => (
  <Layout title="Home">
    <h1>My Trends A3 Project</h1>
    <p>I expand my BRB empire to the ends of the earth.</p>
    <p>I worked on this assignment for 2 hours.</p>
  </Layout>
)

export default IndexPage
