export type Upgrade = {
  id: string
  name: string
  basePrice: number
  incomePerTick: number
}
