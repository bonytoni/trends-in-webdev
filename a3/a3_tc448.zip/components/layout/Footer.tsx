import React from "react";

const Footer = () => (
  <footer>
    <hr />
    <span>Created by [Tony Chen (tc448)]</span>
  </footer>
);

export default Footer;
