export type ClubMember = {
  name: string,
  netid: string,
  partyParrot: string,
  favoriteIceCream: string,
  favoriteTrick: string,
  hobby: string,
}
